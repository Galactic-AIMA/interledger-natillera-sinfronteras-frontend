"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/get-my-loans.ts
var get_my_loans_exports = {};
__export(get_my_loans_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(get_my_loans_exports);

// src/domain.ts
var import_lib_dynamodb2 = require("@aws-sdk/lib-dynamodb");

// src/shared.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var env = {
  natillerasTable: process.env.NATILLERAS_TABLE || "natillera-registration",
  recordsTable: process.env.NATILLERA_RECORDS_TABLE || "natillera-records",
  loansTable: process.env.LOAN_REQUESTS_TABLE || "natillera-loan-request",
  authorIndex: process.env.LOAN_AUTHOR_INDEX || "author-index",
  natilleraIndex: process.env.LOAN_NATILLERA_INDEX || "natillera-index",
  // Interés por cuota sobre el saldo, en puntos básicos (100 = 1 %), igual que el modo demo del front.
  rateBps: BigInt(process.env.LOAN_RATE_BPS || "100"),
  maxInstallments: Number(process.env.LOAN_MAX_INSTALLMENTS || "12")
};
var dynamo = import_lib_dynamodb.DynamoDBDocumentClient.from(new import_client_dynamodb.DynamoDBClient({ region: process.env.AWS_REGION }), {
  marshallOptions: { removeUndefinedValues: true }
});
var HttpError = class extends Error {
  constructor(statusCode, error, message) {
    super(message);
    this.statusCode = statusCode;
    this.error = error;
  }
};
var json = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(body)
});
var isProxy = () => process.env.INTEGRATION_MODE !== "vtl";
var withErrors = (fn) => async (event) => {
  let status;
  let body;
  try {
    const result = await fn(event);
    return isProxy() ? json(200, result) : result;
  } catch (error) {
    if (error instanceof HttpError) {
      status = error.statusCode;
      body = { error: error.error, message: error.message };
    } else {
      console.log("Unhandled error", error);
      status = 500;
      body = { error: "InternalError", message: "Unexpected error" };
    }
  }
  if (isProxy()) return json(status, body);
  throw new Error(`[${status}] ${JSON.stringify(body)}`);
};
var currentIdentity = (event) => {
  let username;
  let sub;
  if (isProxy()) {
    const authorizer = event?.requestContext?.authorizer ?? {};
    const claims = authorizer.jwt?.claims ?? authorizer.claims ?? {};
    username = claims.username ?? claims["cognito:username"];
    sub = claims.sub;
  } else {
    username = event?.auth?.username;
    sub = event?.auth?.sub;
  }
  if (typeof username !== "string" || !username) throw new HttpError(401, "Unauthorized", "Missing username claim");
  return { username, sub: typeof sub === "string" && sub ? sub : void 0 };
};

// src/domain.ts
var buildSchedule = (value, installments, asset, paidCount = 0) => {
  const money = (v) => ({ value: v.toString(), ...asset });
  const n = BigInt(installments);
  const base = value / n;
  const schedule = [];
  let balance = value;
  for (let i = 0; i < installments; i++) {
    const capital = i === installments - 1 ? balance : base;
    const interest = (balance * env.rateBps + 5000n) / 10000n;
    schedule.push({
      n: i + 1,
      capital: money(capital),
      interest: money(interest),
      total: money(capital + interest),
      status: i < paidCount ? "pagada" : "pendiente"
    });
    balance -= capital;
  }
  return schedule;
};
var toRequest = (i) => ({
  requestId: i.requestId,
  natilleraId: i.natilleraId,
  requesterName: i.author,
  amount: i.amount,
  installments: i.installments,
  repaymentAuthorized: Boolean(i.repaymentAuthorized),
  status: i.status,
  createdAt: i.createdAt
});
var queryLoans = async (indexName, field, value) => {
  const items = [];
  let ExclusiveStartKey;
  do {
    const page = await dynamo.send(
      new import_lib_dynamodb2.QueryCommand({
        TableName: env.loansTable,
        IndexName: indexName,
        KeyConditionExpression: `${field} = :v`,
        ExpressionAttributeValues: { ":v": value },
        ExclusiveStartKey
      })
    );
    items.push(...page.Items ?? []);
    ExclusiveStartKey = page.LastEvaluatedKey;
  } while (ExclusiveStartKey);
  return items.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
};
var getMyLoans = async (username) => {
  const mine = await queryLoans(env.authorIndex, "author", username);
  const latest = mine[mine.length - 1];
  if (!latest) return { request: null, loan: null };
  const request = toRequest(latest);
  if (latest.status !== "approved" || !latest.disbursed) return { request, loan: null };
  const asset = { assetCode: latest.amount.assetCode, assetScale: latest.amount.assetScale };
  const schedule = buildSchedule(BigInt(latest.amount.value), latest.installments, asset, latest.paidCount ?? 0);
  const paidCapital = schedule.filter((i) => i.status === "pagada").reduce((acc, i) => acc + BigInt(i.capital.value), 0n);
  return {
    request,
    loan: {
      loanId: `loan-${latest.requestId}`,
      request,
      disbursed: true,
      receivedAmount: latest.receivedAmount,
      balance: { value: (BigInt(latest.amount.value) - paidCapital).toString(), ...asset },
      schedule
    }
  };
};

// src/get-my-loans.ts
var handler = withErrors(async (event) => getMyLoans(currentIdentity(event).username));
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
