"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/simulate-loan.ts
var simulate_loan_exports = {};
__export(simulate_loan_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(simulate_loan_exports);

// src/domain.ts
var import_lib_dynamodb2 = require("@aws-sdk/lib-dynamodb");

// src/shared.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var env = {
  natillerasTable: process.env.NATILLERAS_TABLE || "natillera-registration",
  recordsTable: process.env.NATILLERA_RECORDS_TABLE || "natillera-records",
  loansTable: process.env.LOAN_REQUESTS_TABLE || "natillera-loan-request",
  authorIndex: process.env.LOAN_AUTHOR_INDEX || "author-index",
  natilleraIndex: process.env.LOAN_NATILLERA_INDEX || "natillera-index",
  // Interés por cuota sobre el saldo, en puntos básicos (100 = 1 %), igual que el modo demo del front.
  rateBps: BigInt(process.env.LOAN_RATE_BPS || "100"),
  maxInstallments: Number(process.env.LOAN_MAX_INSTALLMENTS || "12")
};
var dynamo = import_lib_dynamodb.DynamoDBDocumentClient.from(new import_client_dynamodb.DynamoDBClient({ region: process.env.AWS_REGION }), {
  marshallOptions: { removeUndefinedValues: true }
});
var HttpError = class extends Error {
  constructor(statusCode, error, message) {
    super(message);
    this.statusCode = statusCode;
    this.error = error;
  }
};
var json = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(body)
});
var isProxy = () => process.env.INTEGRATION_MODE !== "vtl";
var withErrors = (fn) => async (event) => {
  let status;
  let body;
  try {
    const result = await fn(event);
    return isProxy() ? json(200, result) : result;
  } catch (error) {
    if (error instanceof HttpError) {
      status = error.statusCode;
      body = { error: error.error, message: error.message };
    } else {
      console.log("Unhandled error", error);
      status = 500;
      body = { error: "InternalError", message: "Unexpected error" };
    }
  }
  if (isProxy()) return json(status, body);
  throw new Error(`[${status}] ${JSON.stringify(body)}`);
};
var currentIdentity = (event) => {
  let username;
  let sub;
  if (isProxy()) {
    const authorizer = event?.requestContext?.authorizer ?? {};
    const claims = authorizer.jwt?.claims ?? authorizer.claims ?? {};
    username = claims.username ?? claims["cognito:username"];
    sub = claims.sub;
  } else {
    username = event?.auth?.username;
    sub = event?.auth?.sub;
  }
  if (typeof username !== "string" || !username) throw new HttpError(401, "Unauthorized", "Missing username claim");
  return { username, sub: typeof sub === "string" && sub ? sub : void 0 };
};
var param = (event, name) => {
  const value = isProxy() ? event?.pathParameters?.[name] ?? event?.queryStringParameters?.[name] : event?.params?.[name];
  return typeof value === "string" && value ? value : void 0;
};

// src/domain.ts
var parseValue = (raw) => {
  if (typeof raw !== "string" || !/^[1-9]\d{0,15}$/.test(raw)) {
    throw new HttpError(400, "InvalidAmount", "value must be a positive integer string in minor units");
  }
  return BigInt(raw);
};
var parseInstallments = (raw) => {
  const n = typeof raw === "string" ? Number(raw) : raw;
  if (typeof n !== "number" || !Number.isInteger(n) || n < 1 || n > env.maxInstallments) {
    throw new HttpError(400, "InvalidInstallments", `installments must be an integer between 1 and ${env.maxInstallments}`);
  }
  return n;
};
var parseAsset = (assetCode, assetScale) => {
  const scale = typeof assetScale === "string" ? Number(assetScale) : assetScale;
  if (typeof assetCode !== "string" || !/^[A-Z]{3}$/.test(assetCode) || typeof scale !== "number" || !Number.isInteger(scale) || scale < 0 || scale > 9) {
    throw new HttpError(400, "InvalidAmount", "assetCode (3 letters) and assetScale (0-9) are required");
  }
  return { assetCode, assetScale: scale };
};
var buildSchedule = (value, installments, asset, paidCount = 0) => {
  const money = (v) => ({ value: v.toString(), ...asset });
  const n = BigInt(installments);
  const base = value / n;
  const schedule = [];
  let balance = value;
  for (let i = 0; i < installments; i++) {
    const capital = i === installments - 1 ? balance : base;
    const interest = (balance * env.rateBps + 5000n) / 10000n;
    schedule.push({
      n: i + 1,
      capital: money(capital),
      interest: money(interest),
      total: money(capital + interest),
      status: i < paidCount ? "pagada" : "pendiente"
    });
    balance -= capital;
  }
  return schedule;
};
var highest = (schedule) => schedule.reduce((max, i) => BigInt(i.total.value) > BigInt(max.total.value) ? i : max, schedule[0]).total;
var simulateLoan = (query) => {
  const value = parseValue(query.value);
  const installments = parseInstallments(query.installments);
  const asset = parseAsset(query.assetCode, query.assetScale);
  const amount = { value: value.toString(), ...asset };
  const schedule = buildSchedule(value, installments, asset);
  return { amount, installments, receiveAmount: amount, highestInstallment: highest(schedule), schedule };
};

// src/simulate-loan.ts
var handler = withErrors(async (event) => {
  currentIdentity(event);
  const query = Object.fromEntries(["value", "assetCode", "assetScale", "installments"].map((k) => [k, param(event, k)]));
  return simulateLoan(query);
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
