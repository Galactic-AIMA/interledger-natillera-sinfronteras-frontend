"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/join-natillera.ts
var join_natillera_exports = {};
__export(join_natillera_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(join_natillera_exports);

// src/domain.ts
var import_lib_dynamodb2 = require("@aws-sdk/lib-dynamodb");

// src/shared.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var env = {
  usersTable: process.env.USER_VIEW_TABLE || "user-info",
  savedAccountsTable: process.env.SAVED_ACCOUNTS_TABLE || "saved-accounts",
  natillerasTable: process.env.NATILLERAS_TABLE || "natillera-registration",
  recordsTable: process.env.NATILLERA_RECORDS_TABLE || "natillera-records",
  invitationIndex: process.env.INVITATION_INDEX || "invitation-index",
  walletHosts: (process.env.WALLET_HOSTS || "ilp.interledger-test.dev").split(",").map((h) => h.trim()),
  joinBaseUrl: process.env.JOIN_BASE_URL || "natillera://unirse/"
};
var dynamo = import_lib_dynamodb.DynamoDBDocumentClient.from(new import_client_dynamodb.DynamoDBClient({ region: process.env.AWS_REGION }), {
  marshallOptions: { removeUndefinedValues: true }
});
var HttpError = class extends Error {
  constructor(statusCode, error, message) {
    super(message);
    this.statusCode = statusCode;
    this.error = error;
  }
};
var json = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(body)
});
var isProxy = () => process.env.INTEGRATION_MODE !== "vtl";
var withErrors = (fn) => async (event) => {
  let status;
  let body;
  try {
    const result = await fn(event);
    return isProxy() ? json(200, result) : result;
  } catch (error) {
    if (error instanceof HttpError) {
      status = error.statusCode;
      body = { error: error.error, message: error.message };
    } else {
      console.log("Unhandled error", error);
      status = 500;
      body = { error: "InternalError", message: "Unexpected error" };
    }
  }
  if (isProxy()) return json(status, body);
  throw new Error(`[${status}] ${JSON.stringify(body)}`);
};
var currentIdentity = (event) => {
  let username;
  let sub;
  if (isProxy()) {
    const authorizer = event?.requestContext?.authorizer ?? {};
    const claims = authorizer.jwt?.claims ?? authorizer.claims ?? {};
    username = claims.username ?? claims["cognito:username"];
    sub = claims.sub;
  } else {
    username = event?.auth?.username;
    sub = event?.auth?.sub;
  }
  if (typeof username !== "string" || !username) throw new HttpError(401, "Unauthorized", "Missing username claim");
  return { username, sub: typeof sub === "string" && sub ? sub : void 0 };
};
var parseBody = (event) => {
  if (!isProxy()) {
    return event?.body && typeof event.body === "object" && !Array.isArray(event.body) ? event.body : {};
  }
  if (!event?.body) return {};
  try {
    const raw = event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body;
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    throw new HttpError(400, "BadRequest", "Body must be valid JSON");
  }
};

// src/domain.ts
var normalizeCode = (code) => typeof code === "string" ? code.trim().toUpperCase() : "";
var findByInvitation = async (code) => {
  if (!code) return null;
  const { Items = [] } = await dynamo.send(
    new import_lib_dynamodb2.QueryCommand({
      TableName: env.natillerasTable,
      IndexName: env.invitationIndex,
      KeyConditionExpression: "natilleraInvitation = :c",
      ExpressionAttributeValues: { ":c": code }
    })
  );
  return Items[0] ? getNatillera(Items[0].natilleraId) : null;
};
var getNatillera = async (natilleraId) => {
  const { Item } = await dynamo.send(new import_lib_dynamodb2.GetCommand({ TableName: env.natillerasTable, Key: { natilleraId } }));
  return Item ?? null;
};
var findNatilleraOf = async (username) => {
  let ExclusiveStartKey;
  do {
    const page = await dynamo.send(
      new import_lib_dynamodb2.ScanCommand({
        TableName: env.natillerasTable,
        FilterExpression: "contains(integrants, :u)",
        ExpressionAttributeValues: { ":u": username },
        ExclusiveStartKey
      })
    );
    if (page.Items?.[0]) return page.Items[0];
    ExclusiveStartKey = page.LastEvaluatedKey;
  } while (ExclusiveStartKey);
  return null;
};
var joinNatillera = async (username, body) => {
  const natillera = await findByInvitation(normalizeCode(body.natilleraInvitation));
  if (!natillera) throw new HttpError(404, "InvitationNotFound", "Invitation not found");
  const current = await findNatilleraOf(username);
  if (current && current.natilleraId !== natillera.natilleraId) {
    throw new HttpError(409, "AlreadyMember", "User already belongs to another natillera");
  }
  if (!current) {
    try {
      await dynamo.send(
        new import_lib_dynamodb2.UpdateCommand({
          TableName: env.natillerasTable,
          Key: { natilleraId: natillera.natilleraId },
          UpdateExpression: "SET integrants = list_append(integrants, :me)",
          ConditionExpression: "attribute_exists(natilleraId) AND NOT contains(integrants, :u)",
          ExpressionAttributeValues: { ":me": [username], ":u": username }
        })
      );
    } catch (error) {
      if (error?.name !== "ConditionalCheckFailedException") throw error;
    }
  }
  return getMyNatillera(username);
};
var getMyNatillera = async (username) => {
  const natillera = await findNatilleraOf(username);
  if (!natillera) return null;
  return toView(natillera, username, await listRecords(natillera.natilleraId));
};
var listRecords = async (natilleraId) => {
  const items = [];
  let ExclusiveStartKey;
  do {
    const page = await dynamo.send(
      new import_lib_dynamodb2.QueryCommand({
        TableName: env.recordsTable,
        KeyConditionExpression: "natilleraId = :n",
        ExpressionAttributeValues: { ":n": natilleraId },
        ExclusiveStartKey
      })
    );
    items.push(...page.Items ?? []);
    ExclusiveStartKey = page.LastEvaluatedKey;
  } while (ExclusiveStartKey);
  return items;
};
var monthKey = (iso) => new Date(new Date(iso).getTime() - 5 * 3600 * 1e3).toISOString().slice(0, 7);
var toView = (n, username, records) => {
  const asset = { assetCode: n.assetCode, assetScale: n.assetScale };
  const money = (value) => ({ value: value.toString(), ...asset });
  const valid = records.filter((r) => r.amount?.assetCode === n.assetCode && r.amount?.assetScale === n.assetScale);
  const sum = (rs) => rs.reduce((acc, r) => acc + BigInt(r.amount.value), 0n);
  const thisMonth = monthKey((/* @__PURE__ */ new Date()).toISOString());
  const members = n.integrants.map((id) => {
    const mine = valid.filter((r) => r.author === id);
    const paidThisMonth = mine.some((r) => monthKey(r.createdAt ?? new Date(r.id).toISOString()) === thisMonth);
    return {
      userId: id,
      name: id,
      isAdmin: id === n.author,
      total: money(sum(mine)),
      status: paidThisMonth ? "al-dia" : "debe",
      pendingCount: paidThisMonth ? 0 : 1
    };
  });
  const me = members.find((m) => m.userId === username);
  const fund = sum(valid) - BigInt(n.disbursedTotal ?? "0");
  return {
    natilleraId: n.natilleraId,
    natilleraName: n.natilleraName,
    walletAddress: n.walletAddress,
    asset,
    quota: n.quota,
    invitationCode: n.natilleraInvitation,
    joinUrl: n.joinNatilleraUrl,
    isAdmin: n.author === username,
    fundTotal: money(fund),
    myTotal: me?.total ?? money(0n),
    myStatus: me?.status ?? "al-dia",
    members,
    lastRecords: [...valid].sort((a, b) => b.id - a.id).slice(0, 5).map((r) => ({
      id: String(r.id),
      authorName: r.author,
      paidByName: r.paymentAuthor,
      amount: r.amount,
      createdAt: r.createdAt ?? new Date(r.id).toISOString()
    }))
  };
};

// src/join-natillera.ts
var handler = withErrors(async (event) => joinNatillera(currentIdentity(event).username, parseBody(event)));
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
