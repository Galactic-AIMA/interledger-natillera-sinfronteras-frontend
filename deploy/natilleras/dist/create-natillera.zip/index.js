"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/create-natillera.ts
var create_natillera_exports = {};
__export(create_natillera_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_natillera_exports);

// src/domain.ts
var import_node_crypto = require("node:crypto");
var import_lib_dynamodb2 = require("@aws-sdk/lib-dynamodb");

// src/shared.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var env = {
  usersTable: process.env.USER_VIEW_TABLE || "user-info",
  savedAccountsTable: process.env.SAVED_ACCOUNTS_TABLE || "saved-accounts",
  natillerasTable: process.env.NATILLERAS_TABLE || "natillera-registration",
  recordsTable: process.env.NATILLERA_RECORDS_TABLE || "natillera-records",
  invitationIndex: process.env.INVITATION_INDEX || "invitation-index",
  walletHosts: (process.env.WALLET_HOSTS || "ilp.interledger-test.dev").split(",").map((h) => h.trim()),
  joinBaseUrl: process.env.JOIN_BASE_URL || "natillera://unirse/"
};
var dynamo = import_lib_dynamodb.DynamoDBDocumentClient.from(new import_client_dynamodb.DynamoDBClient({ region: process.env.AWS_REGION }), {
  marshallOptions: { removeUndefinedValues: true }
});
var HttpError = class extends Error {
  constructor(statusCode, error, message) {
    super(message);
    this.statusCode = statusCode;
    this.error = error;
  }
};
var json = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(body)
});
var isProxy = () => process.env.INTEGRATION_MODE !== "vtl";
var withErrors = (fn) => async (event) => {
  let status;
  let body;
  try {
    const result = await fn(event);
    return isProxy() ? json(200, result) : result;
  } catch (error) {
    if (error instanceof HttpError) {
      status = error.statusCode;
      body = { error: error.error, message: error.message };
    } else {
      console.log("Unhandled error", error);
      status = 500;
      body = { error: "InternalError", message: "Unexpected error" };
    }
  }
  if (isProxy()) return json(status, body);
  throw new Error(`[${status}] ${JSON.stringify(body)}`);
};
var currentIdentity = (event) => {
  let username;
  let sub;
  if (isProxy()) {
    const authorizer = event?.requestContext?.authorizer ?? {};
    const claims = authorizer.jwt?.claims ?? authorizer.claims ?? {};
    username = claims.username ?? claims["cognito:username"];
    sub = claims.sub;
  } else {
    username = event?.auth?.username;
    sub = event?.auth?.sub;
  }
  if (typeof username !== "string" || !username) throw new HttpError(401, "Unauthorized", "Missing username claim");
  return { username, sub: typeof sub === "string" && sub ? sub : void 0 };
};
var parseBody = (event) => {
  if (!isProxy()) {
    return event?.body && typeof event.body === "object" && !Array.isArray(event.body) ? event.body : {};
  }
  if (!event?.body) return {};
  try {
    const raw = event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body;
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    throw new HttpError(400, "BadRequest", "Body must be valid JSON");
  }
};
var requiredString = (value, field, max) => {
  const text = typeof value === "string" ? value.trim() : "";
  if (!text || text.length > max) throw new HttpError(400, "BadRequest", `${field} is required (max ${max} chars)`);
  return text;
};

// src/domain.ts
var normalizeWalletUrl = (input) => {
  const raw = typeof input === "string" ? input.trim() : "";
  const candidate = raw.startsWith("$") ? `https://${raw.slice(1)}` : /^[A-Za-z0-9_-]+$/.test(raw) ? `https://${env.walletHosts[0]}/${raw}` : raw;
  let url;
  try {
    url = new URL(candidate);
  } catch {
    throw new HttpError(400, "InvalidWalletAddress", "Invalid wallet address");
  }
  if (url.protocol !== "https:" || !env.walletHosts.includes(url.hostname) || url.username || url.password) {
    throw new HttpError(400, "InvalidWalletAddress", "Wallet address host not allowed");
  }
  return url.href;
};
var lookupWallet = async (input) => {
  const url = normalizeWalletUrl(input);
  let response;
  try {
    response = await fetch(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(5e3) });
  } catch (error) {
    console.log("wallet lookup failed", url, error);
    throw new HttpError(502, "WalletLookupFailed", "Could not reach the wallet address");
  }
  if (!response.ok) return { exists: false, walletAddress: url };
  const data = await response.json().catch(() => null);
  if (!data?.assetCode || !Number.isInteger(data.assetScale)) return { exists: false, walletAddress: url };
  return { exists: true, walletAddress: data.id ?? url, assetCode: data.assetCode, assetScale: data.assetScale };
};
var requireWallet = async (input) => {
  const wallet = await lookupWallet(input);
  if (!wallet.exists) throw new HttpError(400, "InvalidWalletAddress", "Wallet address does not exist");
  return wallet;
};
var CROCKFORD = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
var randomGroup = () => Array.from({ length: 4 }, () => CROCKFORD[(0, import_node_crypto.randomInt)(CROCKFORD.length)]).join("");
var newInvitationCode = (natilleraName) => {
  const word = (natilleraName.normalize("NFD").replace(/[^A-Za-z0-9 ]/g, "").split(" ").find(Boolean) ?? "NAT").toUpperCase().slice(0, 8);
  return `${word || "NAT"}-${randomGroup()}-${randomGroup()}`;
};
var findByInvitation = async (code) => {
  if (!code) return null;
  const { Items = [] } = await dynamo.send(
    new import_lib_dynamodb2.QueryCommand({
      TableName: env.natillerasTable,
      IndexName: env.invitationIndex,
      KeyConditionExpression: "natilleraInvitation = :c",
      ExpressionAttributeValues: { ":c": code }
    })
  );
  return Items[0] ? getNatillera(Items[0].natilleraId) : null;
};
var getNatillera = async (natilleraId) => {
  const { Item } = await dynamo.send(new import_lib_dynamodb2.GetCommand({ TableName: env.natillerasTable, Key: { natilleraId } }));
  return Item ?? null;
};
var defaultQuota = (assetCode, assetScale) => ({
  value: assetCode === "COP" ? String(5e4 * 10 ** assetScale) : String(20 * 10 ** assetScale),
  assetCode,
  assetScale
});
var parseQuota = (value, assetCode, assetScale) => {
  const raw = value && typeof value === "object" ? value.value : value;
  if (raw === void 0 || raw === null || raw === "") return defaultQuota(assetCode, assetScale);
  if (typeof raw !== "string" || !/^[1-9]\d{0,15}$/.test(raw)) {
    throw new HttpError(400, "InvalidAmount", "quota.value must be a positive integer string in minor units");
  }
  return { value: raw, assetCode, assetScale };
};
var createNatillera = async (username, body) => {
  const natilleraName = requiredString(body.natilleraName, "natilleraName", 60);
  const wallet = await requireWallet(body.walletAddress);
  let natilleraInvitation = "";
  for (let attempt = 0; attempt < 5 && !natilleraInvitation; attempt++) {
    const code = newInvitationCode(natilleraName);
    if (!await findByInvitation(code)) natilleraInvitation = code;
  }
  if (!natilleraInvitation) throw new HttpError(500, "InternalError", "Could not generate an invitation code");
  const item = {
    natilleraId: (0, import_node_crypto.randomUUID)(),
    natilleraName,
    author: username,
    integrants: [username],
    walletAddress: wallet.walletAddress,
    assetCode: wallet.assetCode,
    assetScale: wallet.assetScale,
    quota: parseQuota(body.quota, wallet.assetCode, wallet.assetScale),
    natilleraInvitation,
    joinNatilleraUrl: `${env.joinBaseUrl}${natilleraInvitation}`,
    disbursedTotal: "0",
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  await dynamo.send(
    new import_lib_dynamodb2.PutCommand({ TableName: env.natillerasTable, Item: item, ConditionExpression: "attribute_not_exists(natilleraId)" })
  );
  return toView(item, username, []);
};
var monthKey = (iso) => new Date(new Date(iso).getTime() - 5 * 3600 * 1e3).toISOString().slice(0, 7);
var toView = (n, username, records) => {
  const asset = { assetCode: n.assetCode, assetScale: n.assetScale };
  const money = (value) => ({ value: value.toString(), ...asset });
  const valid = records.filter((r) => r.amount?.assetCode === n.assetCode && r.amount?.assetScale === n.assetScale);
  const sum = (rs) => rs.reduce((acc, r) => acc + BigInt(r.amount.value), 0n);
  const thisMonth = monthKey((/* @__PURE__ */ new Date()).toISOString());
  const members = n.integrants.map((id) => {
    const mine = valid.filter((r) => r.author === id);
    const paidThisMonth = mine.some((r) => monthKey(r.createdAt ?? new Date(r.id).toISOString()) === thisMonth);
    return {
      userId: id,
      name: id,
      isAdmin: id === n.author,
      total: money(sum(mine)),
      status: paidThisMonth ? "al-dia" : "debe",
      pendingCount: paidThisMonth ? 0 : 1
    };
  });
  const me = members.find((m) => m.userId === username);
  const fund = sum(valid) - BigInt(n.disbursedTotal ?? "0");
  return {
    natilleraId: n.natilleraId,
    natilleraName: n.natilleraName,
    walletAddress: n.walletAddress,
    asset,
    quota: n.quota,
    invitationCode: n.natilleraInvitation,
    joinUrl: n.joinNatilleraUrl,
    isAdmin: n.author === username,
    fundTotal: money(fund),
    myTotal: me?.total ?? money(0n),
    myStatus: me?.status ?? "al-dia",
    members,
    lastRecords: [...valid].sort((a, b) => b.id - a.id).slice(0, 5).map((r) => ({
      id: String(r.id),
      authorName: r.author,
      paidByName: r.paymentAuthor,
      amount: r.amount,
      createdAt: r.createdAt ?? new Date(r.id).toISOString()
    }))
  };
};

// src/create-natillera.ts
var handler = withErrors(async (event) => createNatillera(currentIdentity(event).username, parseBody(event)));
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
