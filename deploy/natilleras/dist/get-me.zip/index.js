"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/get-me.ts
var get_me_exports = {};
__export(get_me_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(get_me_exports);

// src/domain.ts
var import_lib_dynamodb2 = require("@aws-sdk/lib-dynamodb");

// src/shared.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var env = {
  usersTable: process.env.USER_VIEW_TABLE || "user-info",
  savedAccountsTable: process.env.SAVED_ACCOUNTS_TABLE || "saved-accounts",
  natillerasTable: process.env.NATILLERAS_TABLE || "natillera-registration",
  recordsTable: process.env.NATILLERA_RECORDS_TABLE || "natillera-records",
  invitationIndex: process.env.INVITATION_INDEX || "invitation-index",
  walletHosts: (process.env.WALLET_HOSTS || "ilp.interledger-test.dev").split(",").map((h) => h.trim()),
  joinBaseUrl: process.env.JOIN_BASE_URL || "natillera://unirse/"
};
var dynamo = import_lib_dynamodb.DynamoDBDocumentClient.from(new import_client_dynamodb.DynamoDBClient({ region: process.env.AWS_REGION }), {
  marshallOptions: { removeUndefinedValues: true }
});
var HttpError = class extends Error {
  constructor(statusCode, error, message) {
    super(message);
    this.statusCode = statusCode;
    this.error = error;
  }
};
var json = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(body)
});
var isProxy = () => process.env.INTEGRATION_MODE !== "vtl";
var withErrors = (fn) => async (event) => {
  let status;
  let body;
  try {
    const result = await fn(event);
    return isProxy() ? json(200, result) : result;
  } catch (error) {
    if (error instanceof HttpError) {
      status = error.statusCode;
      body = { error: error.error, message: error.message };
    } else {
      console.log("Unhandled error", error);
      status = 500;
      body = { error: "InternalError", message: "Unexpected error" };
    }
  }
  if (isProxy()) return json(status, body);
  throw new Error(`[${status}] ${JSON.stringify(body)}`);
};
var currentIdentity = (event) => {
  let username;
  let sub;
  if (isProxy()) {
    const authorizer = event?.requestContext?.authorizer ?? {};
    const claims = authorizer.jwt?.claims ?? authorizer.claims ?? {};
    username = claims.username ?? claims["cognito:username"];
    sub = claims.sub;
  } else {
    username = event?.auth?.username;
    sub = event?.auth?.sub;
  }
  if (typeof username !== "string" || !username) throw new HttpError(401, "Unauthorized", "Missing username claim");
  return { username, sub: typeof sub === "string" && sub ? sub : void 0 };
};

// src/domain.ts
var getMe = async (username, sub) => {
  const { Item } = await dynamo.send(new import_lib_dynamodb2.GetCommand({ TableName: env.usersTable, Key: { source: username, id: 1 } }));
  if (!Item) throw new HttpError(404, "UserNotFound", "User not found");
  return {
    userId: sub ?? username,
    username,
    displayName: Item.displayName || username,
    email: Item.email,
    phone: Item.phone ?? Item.phone_number,
    walletAddress: Item.walletAddress,
    assetCode: Item.assetCode,
    assetScale: Item.assetScale
  };
};

// src/get-me.ts
var handler = withErrors(async (event) => {
  const { username, sub } = currentIdentity(event);
  return getMe(username, sub);
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
